#include <iostream>
#include <fstream>
#include "controller.h"
#include "game.h"
#include "renderer.h"
#include "scoreboard.cpp" 

int main() {
  constexpr std::size_t kFramesPerSecond{60};
  constexpr std::size_t kMsPerFrame{1000 / kFramesPerSecond};
  constexpr std::size_t kScreenWidth{640};
  constexpr std::size_t kScreenHeight{640};
  constexpr std::size_t kGridWidth{32};
  constexpr std::size_t kGridHeight{32};

  Renderer renderer(kScreenWidth, kScreenHeight, kGridWidth, kGridHeight);
  Controller controller;
  Game game(kGridWidth, kGridHeight);
  ScoreBoard scoreboard;
  game.Run(controller, renderer, kMsPerFrame);  
  
  std::cout << "\nGame has terminated successfully!\n";
  
  //create a string object for player name
  std::string name;
  
  //prompt user to input their name
  std::cout << "Enter your name: ";
  
  //retrieve user input and store in name object
  std::cin >> name; 
  
  std::cout << "Score: " << game.GetScore() << "\n";
  std::cout << "Size: " << game.GetSize() << "\n";
  
  //add record to the scoreboard
  scoreboard.updateScoreBoard(name, game.GetScore(), game.GetSize());
  scoreboard.printScoreBoard();
  
  return 0;
  
}