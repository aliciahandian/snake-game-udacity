#ifndef SCOREBOARD_H
#define SCOREBOARD_H
#include <fstream>
#include <string>
#include <vector>

struct ScoreEntry{
    std::string name;
    int score;
    int size;
  
  	bool operator<(const ScoreEntry& a) const     //overload the comparison operator to work specifically for this struct
    {
        return score < a.score;  //used solution described in https://stackoverflow.com/questions/4892680/sorting-a-vector-of-structs
    }
};

class ScoreBoard{

public:

    //constructor
    ScoreBoard();

    //getters and setters
    void updateScoreBoard(std::string name, int score, int size);
    void printScoreBoard();

private:

    void sortScoreBoard(); //we want this abstracted away from the user; this will only get called within the class function printScoreBoard()
  
    std::vector<ScoreEntry> _scores; //array of all scores from text file (each record is logged into a ScoreEntry object then added to the array)
    std::ofstream _scorefile; //stream used to check for score text file
    std::string _filepath = "scores.txt"; //set file name 
  
};

#endif