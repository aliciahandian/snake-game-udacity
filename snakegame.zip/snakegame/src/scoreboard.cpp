#include "scoreboard.h"
#include <iostream>
#include <sstream>
#include <algorithm>
#include <string>
#include <fstream>

ScoreBoard::ScoreBoard(){ //ScoreBoard constructor

    _scorefile.open(_filepath, std::ios::app ); //open the file in APPEND mode so that avoid overwriting it completely later

    //check if score file has been previously created
    if(_scorefile){

      	_scorefile.close(); //close file in order to avoid issues during update process

    }

    //if score file was not created during a previous run of the game then we make a new file
    else{

        std::ofstream {_filepath}; //creates new score file 
     	_scorefile.close(); //close file in order to avoid issues during update process

    }
  
}

void ScoreBoard::updateScoreBoard(std::string name, int score, int size){ //ScoreBoard setter

  	//std::cout << "\nUpdating file...\n"; 
    _scorefile.open(_filepath, std::ios::app ); //open the file in APPEND mode so that we add the new line at the end of the file instead of overwriting it
  	
 	_scorefile << name << "," << std::to_string(score) << "," << std::to_string(size) << "\n" ;
  
    _scorefile.close();

}

void ScoreBoard::printScoreBoard(){ //ScoreBoard Getter
  
  	ScoreBoard::sortScoreBoard(); //sort the scores in the files from highest to lowest
  
  	std::cout << "\nCURRENT TOP 3 HIGH SCORES:\n";  //declare scoreboard
    std::cout << "-------------------------- \n";
  	std::cout << " NAME  |  SCORE  |  SIZE   \n";   //specify scoreboard format
 	std::cout << "-------------------------- \n";
  
  	for(int i = 0; i < 3; i++){                     //loops three times so we print the top three high scores
      
  		std::cout << _scores[i].name << " : " << std::to_string(_scores[i].score)   //prints out scores on the previously specified format
          	 	  << " : " << std::to_string(_scores[i].size) << "\n";          
      }
}

void ScoreBoard::sortScoreBoard(){ //Formats the records from score text file as ScoreEntry Objects, stores them ina  vector, and sorts them from highest to lowest
  
  std::ifstream filestream(_filepath); //create a temporary ifstream so we can simply read the text file
  std::string line, name, score, size;       //create tokens that we will use while reading from ifstream
  
  if (filestream.is_open()) {                               //check if file has opened successfully
    
    while (std::getline(filestream, line)) {                //while we still have lines to read from the file...
      
      std::replace(line.begin(), line.end(), ',', ' ');     //replace every comma with a space so we can tokenize the string
      std::istringstream linestream(line);                  //declare another stream for each line
      
      while (linestream >> name >> score >> size) {         //while we have three respective tokens in each line of the text file
        
        ScoreEntry entry;                                   //create a score entry object
        entry.name = name;                                  //record the name token into the name of the entry object
        entry.score = std::stoi(score);                     //record the score token into the score of the entry object
        entry.size = std::stoi(size);                       //record the size token into the size of the entry object
        
        _scores.push_back(entry);                            //add the entry object to the _scores vector
        
      }
    }
  } 
  
  std::sort(_scores.begin(), _scores.end()); //sort the vector from lowest score to highest score
  std::reverse(_scores.begin(), _scores.end()); //reverse the vector so that it's ordered from highest score to lowest score
}